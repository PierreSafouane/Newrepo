package project_java0;

public class Ex2 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		//UtilTab.somme(5, 4);
		
		//double tab[] = {1,2,3,4,5};
		
		//UtilTab.incre(tab, 2);
		
		//double[] t = new double [25];
		//t = UtilTab.genere(3);
		
		//UtilTab.aff(t);
		
//		double taba[] = {1,2,3,4,5};
//		double tabb[] = {1,2,3,4,5};
//		
//		double tabc[] = UtilTab.sum(taba, tabb);
//		UtilTab.aff(tabc);
		
//		String str = "Bonjoullllllr";
//		String str2 = "Bonjour";
//		
//		String str3 = new String("Bonjour");
//		String str4 = new String("Bonjour");
//		
//		
//		str = str3;
//		
//		if(str == str2)
//			System.out.println("==");
//		else
//			System.out.println("!=");
//		
//		
//		UtilTab util = new UtilTab();
		
//		double b = 1515151545.;
//		long a = 2147483649;
		
//		util.add(a,b);
		
		
		
	}
	
}
