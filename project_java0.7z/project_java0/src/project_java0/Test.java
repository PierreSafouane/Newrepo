package project_java0;

public class Test {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		short p = 200;
		byte b1 = 10;
		byte b2 = 20;
		byte test = (byte) (p+b1);
		byte y = b1+b2;
		long l = 50;
		int v = 20;
		int u = l+v;
		float te = 6;
		long ec = 5;
		float aa = te+ec;
		double z = 15;
		float t = aa+z;
		float et = 1*(10^38);
		System.out.println(p+b1);
		System.out.println(test);
	}
	
}
