package project_java0;

public class UtilTab {

	public static void somme(double a, double b) {
		double somme = a + b;
		System.out.println(somme);
	}

	public static void incre(double tab[], double increment) {
		for (int i = 0; i < tab.length; i++) {
			tab[i] += increment;
			System.out.println(tab[i]);
		}
	}

	public static double [] genere (int n) {
		double tab[] = new double [n];
		int j= 1;
		for (int i = 0; i<n;i++,j+=2) {
			tab[i]=j;
		}
		return tab;
	}
	
	public static void aff (double [] tab) {
		for (int i = 0 ; i <tab.length;i++) {
			System.out.println(tab[i]);
		}
	}
	
	public static double [] sum (double tab1 [], double tab2 []) {
		double tab3 [] = new double [tab1.length];
		
		for (int i = 0 ; i < tab1.length; i++) {
			tab3[i] = tab1[i]+tab2[i];
		}
		return tab3;
	}
	
	public static void add (double ...a) { // m�thode qui permet d'additionner un nb illimit� de nombres
        double sum = 0;
        for (double i: a)
               sum +=i;
        System.out.println(sum);
	}
	
	public static <T> void generique (T attribut) { // m�thode qui permet d'additionner un nb illimit� de nombres
	       
        System.out.print( attribut);
      
    
	}

}
