package project_java0;

public class Char {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		char c = 60;
		byte b = 10;
		char ce = 'e';
		char cg = 'g';
		System.out.println(b*c);
		
		byte u = 30;
		byte o = 100;
		System.out.println(u+o);
		
		byte t = (byte) 500;
		
		System.out.println(t);
		
		char pa = (char) (cg-ce);
		System.out.println(pa);
		
		int i = 15;
		int n = i+=3;
		System.out.println(n);
		
	}

}
