package fr.formation.afpa.tp_exception;

public class ErrDiff extends ErrNat {

	public ErrDiff(double a) {
		super(a);
	}

}
