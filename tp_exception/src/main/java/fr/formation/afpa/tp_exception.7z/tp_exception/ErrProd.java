package fr.formation.afpa.tp_exception;

public class ErrProd extends ErrNat {

	public ErrProd(double a) {
		super(a);
	}

}
