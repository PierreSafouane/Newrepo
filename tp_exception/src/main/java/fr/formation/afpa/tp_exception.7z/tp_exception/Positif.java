package fr.formation.afpa.tp_exception;

public class Positif {
	
	int n;
	
	public Positif(int n) throws ErrConst {
		
		if(n<0) {
			throw new ErrConst(n);
		}
		this.n = n;
	}
	
	public static int Somme (int a, int b) throws ErrSom {
		int s = a +b;
		if (s>2147483647) {
			throw new ErrSom(s);
		}
		return s;
	}

	public int getN() {
		return n;
	}
	
	

}
