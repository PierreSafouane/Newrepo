package fr.formation.afpa.tp_exception;

public class ErrConst extends ErrNat {
	
	int Erreur;
	
	public ErrConst(int a) {
		Erreur = a;
	}

}
