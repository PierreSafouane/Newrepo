package fr.formation.afpa.tp_exception;

public class ErrSom extends ErrNat {

	public ErrSom(double a) {
		super(a);
	}

}
