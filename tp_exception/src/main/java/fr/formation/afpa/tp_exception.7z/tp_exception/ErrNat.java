package fr.formation.afpa.tp_exception;

public class ErrNat extends Exception {
	
	public ErrNat() {
		
	}

}
